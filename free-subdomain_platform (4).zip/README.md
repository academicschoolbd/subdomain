# Free Subdomain Platform — institution.bd & smartschool.bd  (v2.1)

A free verified-subdomain platform for every Bangladeshi school, college,
university, madrasa, polytechnic, training institute and NGO.

> **v2.1 additions** (on top of v2):
> - Realtime homepage tiles: **Users registered · Domains claimed · Pending · Rejected** (auto-refresh every 30 s).
> - **Profile gate** before claiming — collects Full Name, Mobile, পদবি (designation), প্রতিষ্ঠানের নাম, বিভাগ, জেলা, উপজেলা once per user.
> - All pages now served as **`.php`** files (`index.php`, `claim.php`, …). Pretty URLs (`/claim`, `/directory`, …) still work via `.htaccess`.
>
> **v2 highlights:** social sign-in (Google / Facebook / GitHub), floating
> WhatsApp support button, "Join WhatsApp community" section, fully
> responsive modern homepage with dynamic AJAX, brand-new vanilla-JS
> frontend (no build step), all pages served as PHP/HTML with a
> shared PHP 8 API.

Drops straight into **shared cPanel hosting** — pure PHP 8 + SQLite (or
MySQL if you prefer) + static HTML/CSS/JS. **No Composer, no Node, no
build step on the server.**

---

## What's in the box

```
free-subdomain_platform/
├── .htaccess              Apache rewrites: API, uploads, pretty URLs
├── index.php             Homepage (hero, dynamic stats, directory preview, WA community)
├── directory.php         AJAX directory with filters
├── claim.php             3-step claim wizard (subdomain → details → docs)
├── dashboard.php         Owner dashboard (claims, profile, images, notices, docs)
├── admin.php             Admin moderation console
├── institution.php       Single-tenant public page
├── auth/
│   └── callback.php      OAuth landing — decodes token from URL fragment
├── assets/
│   ├── css/style.css      Modern, mobile-first stylesheet
│   ├── js/
│   │   ├── app.js         Shared module (API client, auth, OAuth modal, WA float, toasts)
│   │   ├── home.js / directory.js / institution.js / claim.js
│   │   ├── dashboard.js / admin.js / auth-callback.js
│   └── img/               Logo, favicon, WhatsApp + Google/FB/GitHub icons
├── api/                   PHP 8 backend
│   ├── index.php          Front controller
│   ├── bootstrap.php      Loads config, init DB, init schema, seed
│   ├── config.example.php Copy to config.php and edit
│   ├── .htaccess          Locks down lib/, routes/, config files
│   ├── data/              SQLite database lives here (auto-created)
│   ├── lib/               auth, db, slug, cloudflare, http  (OAuth helpers)
│   └── routes/            auth.php, claim.php, admin.php, public.php
├── uploads/               Writable; logos, banners, docs land here
├── database/install.sql   OPTIONAL — only for MySQL
├── router.php             Local dev only: `php -S 127.0.0.1:8080 router.php`
├── INSTALL.md             Step-by-step cPanel + OAuth setup guide
└── README.md              This file
```

---

## Features

### Public
- Modern hero with gradient background, dynamic stats (verified / pending / seeded counts via AJAX).
- Slug availability checker that updates as you type (debounced, ~300 ms).
- Directory with AJAX filtering: brand, category, division, search-as-you-type, pagination.
- Per-institution page at `/i/<brand>/<slug>` (in production: `<slug>.<brand>` via wildcard DNS).
- Notice board on each verified institution.
- "Join WhatsApp community" call-to-action band on the homepage and in the footer.
- Floating WhatsApp support button on every page (pulse animation, bottom-right corner).

### Owners — social sign-in (Google / Facebook / GitHub)
- One-click sign-in via Google, Facebook or GitHub. **No phone OTP, no passwords.**
- Multi-step claim wizard: brand → slug check → details → document upload → submit.
- Live slug-availability check that respects admin-reserved words.
- Dashboard showing every claim with status badges (pending / needs info / verified / rejected / suspended / seeded).
- Tenant editor: profile, logo + banner upload, document upload, notice CRUD, DNS status panel.

### Admin
- Moderation queue with filter by status + search by name/slug/EIIN.
- Per-claim detail view with all uploaded documents (private — only admins can download).
- Four decisions: Approve · Needs info · Reject · Suspend (each with notes shown to the owner).
- On Approve → DNS record is auto-created in Cloudflare. On Reject/Suspend → record is deleted.
- DNS retry button for any approved claim whose Cloudflare call previously failed.
- Reserved-slugs manager (add/delete blocked subdomains).
- Stats dashboard (totals by status + total users).

### Cloudflare auto-DNS (optional)
- Paste a scoped API token + each brand's Zone ID + your server IP into `config.php`.
- Approve → POST to `/zones/{zone_id}/dns_records`.
- Reject/Suspend → DELETE the record.
- Leave the fields blank to disable — the platform works fine without it.

---

## What changed since v1

| | v1 | v2 |
|---|---|---|
| Sign-in | Phone-OTP (Bangladesh mobile) | Google / Facebook / GitHub OAuth (passwordless) |
| Frontend | React + Vite build | Vanilla HTML + CSS + JS — **no build step** |
| Homepage | Static hero + search | Dynamic stats, AJAX availability check, directory preview, WhatsApp community band |
| Support | (none) | Floating WhatsApp icon site-wide |
| Pretty URLs | SPA fallback only | Real pages with `/directory`, `/claim`, `/dashboard`, `/admin`, `/i/<brand>/<slug>` |
| Migration | n/a | Idempotent — existing v1 SQLite/MySQL data is auto-upgraded |

Phone-OTP routes are still mounted (`/api/auth/request-otp`, `/api/auth/verify-otp`)
for backwards compatibility, but the UI no longer surfaces them.

---

## Quick start — local

```bash
cd free-subdomain_platform/
cp api/config.example.php api/config.php   # then edit jwt_secret + OAuth client IDs
php -S 127.0.0.1:8080 router.php
```

Open <http://127.0.0.1:8080>.

For local OAuth testing, register each provider's app with redirect URI
`http://127.0.0.1:8080/api/auth/oauth/<provider>/callback` and update
`'site_url' => 'http://127.0.0.1:8080'` in `config.php`.

---

## Production deploy (cPanel)

See **INSTALL.md** for the full step-by-step. Short version:

1. Unzip into `public_html/` so that `public_html/index.php`, `public_html/api/`, `public_html/uploads/`, and `public_html/auth/callback.php` all exist.
2. Copy `api/config.example.php` → `api/config.php`. Edit `site_url`, `jwt_secret`, `admin_email`, OAuth client IDs + secrets, and WhatsApp numbers/links.
3. Register OAuth apps with Google / Facebook / GitHub. Redirect URIs all follow the pattern `https://institution.bd/api/auth/oauth/<provider>/callback`.
4. Make `api/data/` and `uploads/` writable (`chmod 0775`).
5. (Optional, for MySQL) create a DB in cPanel, import `database/install.sql`, set `db_driver => 'mysql'` plus credentials in `config.php`.
6. (Optional, for auto-DNS) fill the `cloudflare` block in `config.php`.
7. In Cloudflare set wildcard DNS for `*.institution.bd` and `*.smartschool.bd` → your server IP.
8. Visit `https://institution.bd/api/healthz` — you should see `{"ok":true,...}`.

That's it. The first request auto-creates the database schema, seeds the
reserved-slug list, and inserts demo data.

---

## OAuth provider quick-links

| Provider | Console | What you'll paste back |
|---|---|---|
| Google | https://console.cloud.google.com/apis/credentials | Client ID + Client secret |
| Facebook | https://developers.facebook.com/apps/ | App ID + App secret |
| GitHub | https://github.com/settings/developers | Client ID + Client secret |

Redirect URI (all three providers):
`https://institution.bd/api/auth/oauth/<provider>/callback`

You can enable **any subset** — leave a provider's `client_id` blank in
`config.php` to hide that button on the login modal. At least one
provider must be enabled.

---

## Default admin

Set `admin_email` in `config.php` to the email you'll use with Google /
Facebook / GitHub. The first time you sign in with that account, your
user row is auto-promoted to admin (`is_admin = 1`).

Legacy fallback: `admin_phone => '01700000000'` still works if you call the
phone-OTP API directly, but the UI no longer surfaces it.

---

## Tech notes

- **Backend:** plain PHP 8 + PDO (SQLite or MySQL). No Composer dependencies.
- **Frontend:** vanilla HTML + CSS + JS. No bundler, no Node, no build.
- **Auth:** stateless JWT in `Authorization: Bearer …` header (14-day TTL). OAuth state token stored in `oauth_states` for CSRF protection (10-minute TTL).
- **Token transport:** after OAuth callback, the JWT is returned to the browser as a URL **fragment** (`#payload=…`) so it never hits server logs.
- **Upload limits:** 4 MB images (logo/banner), 8 MB documents (NID/EIIN/board letter).
- **Reserved slugs:** 40+ defaults seeded on first boot. Admin UI can add/remove at any time.
- **Idempotent migrations:** the bootstrap routine adds the new `email`, `name`, `avatar_url`, `provider`, `provider_id` columns to `users` if they don't exist, so v1 → v2 upgrades just work.

---

## License

Use, modify, and ship freely. No warranty.
