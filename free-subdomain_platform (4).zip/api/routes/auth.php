<?php
declare(strict_types=1);

/** Auth routes: request-otp, verify-otp, me. */

function route_auth_request_otp(array $CONFIG): void
{
    $data = read_json_body();
    $phone = normalize_phone((string)require_param($data, 'phone'));
    if (!is_valid_bd_phone($phone)) {
        send_error('Enter a valid Bangladesh mobile number (e.g. 01712345678).');
    }
    // Light rate-limit: max 5 OTPs per phone per hour.
    $stmt = db($CONFIG)->prepare(
        "SELECT COUNT(*) c FROM otps WHERE phone = ? AND created_at > ?"
    );
    $stmt->execute([$phone, date('Y-m-d H:i:s', time() - 3600)]);
    if ((int)$stmt->fetch()['c'] >= 5) {
        send_error('Too many OTP requests. Try again in an hour.', 429);
    }
    $code = create_otp($CONFIG, $phone);
    audit($CONFIG, null, null, 'auth.request_otp', json_encode(['phone' => $phone]));
    $resp = ['ok' => true, 'phone' => $phone, 'expires_in_seconds' => 600];
    if (!empty($CONFIG['demo_mode'])) {
        $resp['dev_code'] = $code; // shown only in demo mode for testing
        $resp['demo_note'] = 'Demo mode: code returned in response. Set demo_mode = false in config.php for production and wire SMS gateway.';
    }
    send_json($resp);
}

function route_auth_verify_otp(array $CONFIG): void
{
    $data = read_json_body();
    $phone = normalize_phone((string)require_param($data, 'phone'));
    $code = (string)require_param($data, 'code');
    if (!verify_otp($CONFIG, $phone, $code)) {
        send_error('Invalid or expired code.', 401);
    }
    $pdo = db($CONFIG);
    $stmt = $pdo->prepare('SELECT id, phone, email, name, is_admin FROM users WHERE phone = ?');
    $stmt->execute([$phone]);
    $user = $stmt->fetch();
    if (!$user) {
        $pdo->prepare(
            'INSERT INTO users (phone, is_admin, created_at) VALUES (?,?,?)'
        )->execute([$phone, 0, db_now($CONFIG)]);
        $stmt->execute([$phone]);
        $user = $stmt->fetch();
    }
    $user['is_admin'] = (bool)$user['is_admin'];
    $token = jwt_issue($CONFIG, (int)$user['id'], $user['is_admin']);
    audit($CONFIG, (int)$user['id'], null, 'auth.login');
    send_json(['ok' => true, 'token' => $token, 'user' => $user]);
}

function route_auth_me(array $CONFIG): void
{
    $u = require_user($CONFIG);
    send_json(['user' => $u]);
}

/* =================================================================== */
/*  Email + password auth (fallback when OAuth is unavailable)           */
/* =================================================================== */

/** Normalize emails for lookup: trim + lowercase. */
function _norm_email(string $e): string
{
    return strtolower(trim($e));
}

/** Basic email format check — RFC-grade is overkill for sign-up. */
function _is_valid_email(string $e): bool
{
    return (bool)filter_var($e, FILTER_VALIDATE_EMAIL);
}

/**
 * POST /api/auth/register
 * Body: { name, email, password, mobile? }
 * Creates an account and returns { ok, token, user }.
 */
function route_auth_register(array $CONFIG): void
{
    $data = read_json_body();
    $name     = trim((string)($data['name'] ?? ''));
    $email    = _norm_email((string)($data['email'] ?? ''));
    $password = (string)($data['password'] ?? '');
    $mobile   = trim((string)($data['mobile'] ?? ''));

    $errors = [];
    if ($name === '')                            $errors['name']     = 'Please enter your name.';
    if ($email === '')                           $errors['email']    = 'Email is required.';
    elseif (!_is_valid_email($email))            $errors['email']    = 'That email looks invalid.';
    if (strlen($password) < 8)                   $errors['password'] = 'Password must be at least 8 characters.';
    if ($mobile !== '' && !is_valid_bd_phone($mobile)) {
        $errors['mobile'] = 'Enter a valid Bangladesh mobile or leave blank.';
    }
    if ($errors) {
        send_json(['ok' => false, 'errors' => $errors], 422);
    }

    $pdo = db($CONFIG);
    $stmt = $pdo->prepare('SELECT id, password_hash FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $existing = $stmt->fetch() ?: null;

    if ($existing && !empty($existing['password_hash'])) {
        send_json([
            'ok' => false,
            'errors' => ['email' => 'An account with this email already exists. Try signing in instead.'],
        ], 409);
    }

    $hash = password_hash($password, PASSWORD_BCRYPT);
    $mobileNorm = $mobile !== '' ? normalize_phone($mobile) : null;
    $now = db_now($CONFIG);

    if ($existing) {
        // OAuth-only account — attach a password so the user can sign in by email too.
        $pdo->prepare(
            'UPDATE users
                SET password_hash = ?,
                    name = COALESCE(NULLIF(name, ""), ?),
                    mobile = COALESCE(NULLIF(mobile, ""), ?)
              WHERE id = ?'
        )->execute([$hash, $name, $mobileNorm, (int)$existing['id']]);
        $userId = (int)$existing['id'];
    } else {
        $isAdmin = 0;
        $adminEmail = _norm_email((string)($CONFIG['admin_email'] ?? ''));
        if ($adminEmail !== '' && $adminEmail === $email) {
            $isAdmin = 1;
        }
        $pdo->prepare(
            'INSERT INTO users (email, name, mobile, password_hash, provider, is_admin, created_at)
             VALUES (?,?,?,?,?,?,?)'
        )->execute([$email, $name, $mobileNorm, $hash, 'email', $isAdmin, $now]);
        $userId = (int)$pdo->lastInsertId();
    }

    $cols = _user_select_cols($CONFIG);
    $stmt = $pdo->prepare("SELECT $cols FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    $user['is_admin'] = (bool)$user['is_admin'];
    $user['profile_complete'] = profile_is_complete($user);
    $user['profile_missing']  = profile_missing_fields($user);

    $token = jwt_issue($CONFIG, $userId, $user['is_admin']);
    audit($CONFIG, $userId, null, 'auth.register.email');
    send_json(['ok' => true, 'token' => $token, 'user' => $user]);
}

/**
 * POST /api/auth/login
 * Body: { email, password }
 * Returns { ok, token, user } or 401.
 */
function route_auth_login(array $CONFIG): void
{
    $data = read_json_body();
    $email    = _norm_email((string)($data['email'] ?? ''));
    $password = (string)($data['password'] ?? '');

    if ($email === '' || $password === '') {
        send_json(['ok' => false, 'errors' => ['email' => 'Enter your email and password.']], 422);
    }

    $pdo = db($CONFIG);
    $stmt = $pdo->prepare('SELECT id, password_hash, is_admin FROM users WHERE email = ? LIMIT 1');
    $stmt->execute([$email]);
    $row = $stmt->fetch() ?: null;

    if (!$row || empty($row['password_hash']) || !password_verify($password, (string)$row['password_hash'])) {
        // Constant-ish response — same shape whether the email is unknown or
        // the password is wrong, so attackers can't enumerate accounts.
        send_json(['ok' => false, 'errors' => ['password' => 'Incorrect email or password.']], 401);
    }

    $userId = (int)$row['id'];
    $isAdmin = (bool)$row['is_admin'];
    $cols = _user_select_cols($CONFIG);
    $stmt = $pdo->prepare("SELECT $cols FROM users WHERE id = ?");
    $stmt->execute([$userId]);
    $user = $stmt->fetch();
    $user['is_admin'] = (bool)$user['is_admin'];
    $user['profile_complete'] = profile_is_complete($user);
    $user['profile_missing']  = profile_missing_fields($user);

    $token = jwt_issue($CONFIG, $userId, $isAdmin);
    audit($CONFIG, $userId, null, 'auth.login.email');
    send_json(['ok' => true, 'token' => $token, 'user' => $user]);
}

/**
 * PATCH /api/auth/profile  —  save the "tell us about yourself" fields the
 * user is required to complete before claiming a subdomain.
 *
 * Body (all required to mark the profile complete):
 *   name, mobile, designation_bn, institution_name, division, district, upazila
 */
function route_auth_profile_patch(array $CONFIG): void
{
    $u = require_user($CONFIG);
    $data = read_json_body();

    $get = static function (array $d, string $k): string {
        return trim((string)($d[$k] ?? ''));
    };

    $name             = $get($data, 'name');
    $mobile           = $get($data, 'mobile');
    $designation_bn   = $get($data, 'designation_bn');
    $institution_name = $get($data, 'institution_name');
    $division         = $get($data, 'division');
    $district         = $get($data, 'district');
    $upazila          = $get($data, 'upazila');

    // Validation: mobile must look like a BD number; everything else just non-empty.
    $errors = [];
    if ($name === '')             $errors['name']             = 'Full name required';
    if ($mobile === '')           $errors['mobile']           = 'Mobile number required';
    elseif (!is_valid_bd_phone($mobile)) {
        $errors['mobile'] = 'Enter a valid Bangladesh mobile (e.g. 01712345678)';
    }
    if ($designation_bn === '')   $errors['designation_bn']   = 'পদবি / Designation required';
    if ($institution_name === '') $errors['institution_name'] = 'প্রতিষ্ঠানের নাম / Institution name required';
    if ($division === '')         $errors['division']         = 'বিভাগ / Division required';
    if ($district === '')         $errors['district']         = 'জেলা / District required';
    if ($upazila === '')          $errors['upazila']          = 'উপজেলা / Upazila required';

    if ($errors) {
        send_json(['ok' => false, 'errors' => $errors], 422);
    }

    $mobileNorm = normalize_phone($mobile);
    $pdo = db($CONFIG);
    $pdo->prepare(
        'UPDATE users SET
            name = ?, mobile = ?, designation_bn = ?, institution_name = ?,
            division = ?, district = ?, upazila = ?, profile_completed_at = ?
         WHERE id = ?'
    )->execute([
        $name, $mobileNorm, $designation_bn, $institution_name,
        $division, $district, $upazila, db_now($CONFIG), (int)$u['id'],
    ]);
    audit($CONFIG, (int)$u['id'], null, 'auth.profile.update');

    // Return fresh user row so the frontend can update localStorage.
    $cols = _user_select_cols($CONFIG);
    $stmt = $pdo->prepare("SELECT $cols FROM users WHERE id = ?");
    $stmt->execute([(int)$u['id']]);
    $user = $stmt->fetch();
    $user['is_admin'] = (bool)$user['is_admin'];
    $user['profile_complete'] = profile_is_complete($user);
    $user['profile_missing']  = profile_missing_fields($user);
    send_json(['ok' => true, 'user' => $user]);
}

/* =================================================================== */
/*  OAuth                                                                */
/* =================================================================== */

function _oauth_html_redirect(string $url): void
{
    // Tiny HTML redirect so we can pass a token in the URL fragment (#token=…)
    // without it ever hitting the server logs.
    $safe = htmlspecialchars($url, ENT_QUOTES);
    header('Content-Type: text/html; charset=utf-8');
    echo "<!doctype html><meta charset=utf-8><title>Signing you in…</title>
<meta name=\"robots\" content=\"noindex\">
<script>window.location.replace(" . json_encode($url) . ");</script>
<p>Redirecting… If nothing happens, <a href=\"{$safe}\">click here</a>.</p>";
    exit;
}

function _oauth_finish_redirect(array $CONFIG, ?string $next, array $result): void
{
    // Land the user on /auth/callback.php with the result in the URL fragment.
    $base = rtrim((string)($CONFIG['site_url'] ?? ''), '/');
    if ($base === '') {
        $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $base = $scheme . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost');
    }
    // Encode result as a URL-safe base64 JSON blob.
    $payload = rtrim(strtr(base64_encode(json_encode($result)), '+/', '-_'), '=');
    $next = $next !== null && $next !== '' ? $next : '/';
    $url = $base . '/auth/callback.php#payload=' . $payload
         . '&next=' . rawurlencode($next);
    _oauth_html_redirect($url);
}

function route_auth_oauth_start(array $CONFIG, string $provider): void
{
    $enabled = oauth_enabled_providers($CONFIG);
    if (!isset($enabled[$provider])) {
        send_error('OAuth provider not configured: ' . $provider, 404);
    }
    $next = (string)($_GET['next'] ?? '/');
    $state = oauth_create_state($CONFIG, $provider, $next);
    $meta = $enabled[$provider];
    $params = [
        'client_id'     => $CONFIG['oauth'][$provider]['client_id'],
        'redirect_uri'  => oauth_redirect_uri($CONFIG, $provider),
        'response_type' => 'code',
        'scope'         => $meta['scope'],
        'state'         => $state,
    ];
    if ($provider === 'google') {
        $params['access_type'] = 'online';
        $params['prompt'] = 'select_account';
    }
    if ($provider === 'github') {
        $params['allow_signup'] = 'true';
    }
    $url = $meta['auth_url'] . '?' . http_build_query($params);
    header('Location: ' . $url, true, 302);
    exit;
}

function route_auth_oauth_callback(array $CONFIG, string $provider): void
{
    $enabled = oauth_enabled_providers($CONFIG);
    if (!isset($enabled[$provider])) {
        send_error('OAuth provider not configured: ' . $provider, 404);
    }
    $code = (string)($_GET['code'] ?? '');
    $state = (string)($_GET['state'] ?? '');
    $err = (string)($_GET['error'] ?? '');
    if ($err) {
        _oauth_finish_redirect($CONFIG, null, [
            'ok' => false,
            'error' => $err . ': ' . (string)($_GET['error_description'] ?? ''),
        ]);
    }
    if ($code === '' || $state === '') {
        _oauth_finish_redirect($CONFIG, null, ['ok' => false, 'error' => 'Missing code/state']);
    }
    $st = oauth_consume_state($CONFIG, $state, $provider);
    if (!$st) {
        _oauth_finish_redirect($CONFIG, null, ['ok' => false, 'error' => 'Invalid or expired state']);
    }
    $profile = oauth_fetch_profile($CONFIG, $provider, $code);
    if (!$profile || ($profile['provider_id'] === '')) {
        _oauth_finish_redirect($CONFIG, $st['redirect'], ['ok' => false, 'error' => 'Could not retrieve profile from ' . $provider]);
    }
    $user = oauth_upsert_user($CONFIG, $profile);
    $token = jwt_issue($CONFIG, (int)$user['id'], (bool)$user['is_admin']);
    audit($CONFIG, (int)$user['id'], null, 'auth.oauth.' . $provider);
    _oauth_finish_redirect($CONFIG, $st['redirect'], [
        'ok' => true,
        'token' => $token,
        'user' => $user,
    ]);
}
