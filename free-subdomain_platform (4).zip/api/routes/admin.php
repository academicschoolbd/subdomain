<?php
declare(strict_types=1);

/** Admin routes: moderation queue, decide, documents, stats, reserved-slug CRUD. */

function route_admin_stats(array $CONFIG): void
{
    require_admin($CONFIG);
    $pdo = db($CONFIG);
    $byStatus = $pdo->query('SELECT status, COUNT(*) c FROM institutions GROUP BY status')->fetchAll();
    $counts = ['total' => 0, 'verified' => 0, 'pending' => 0, 'needs_info' => 0, 'rejected' => 0, 'seeded' => 0, 'suspended' => 0];
    foreach ($byStatus as $r) {
        $counts['total'] += (int)$r['c'];
        $counts[$r['status']] = (int)$r['c'];
    }
    $users = (int)$pdo->query('SELECT COUNT(*) c FROM users')->fetch()['c'];
    $admins = (int)$pdo->query('SELECT COUNT(*) c FROM users WHERE is_admin = 1')->fetch()['c'];
    send_json(['counts' => $counts, 'users' => $users, 'admins' => $admins]);
}

function route_admin_list_claims(array $CONFIG): void
{
    require_admin($CONFIG);
    $status = $_GET['status'] ?? 'pending';
    $q = trim((string)($_GET['q'] ?? ''));
    $limit = max(1, min(100, (int)($_GET['limit'] ?? 50)));
    $offset = max(0, (int)($_GET['offset'] ?? 0));
    $where = [];
    $bind = [];
    if ($status !== 'any') { $where[] = 'status = ?'; $bind[] = $status; }
    if ($q !== '') {
        $where[] = '(name_en LIKE ? OR name_bn LIKE ? OR slug LIKE ? OR eiin LIKE ?)';
        $like = '%' . $q . '%';
        array_push($bind, $like, $like, $like, $like);
    }
    $sql = 'SELECT * FROM institutions';
    if ($where) $sql .= ' WHERE ' . implode(' AND ', $where);
    $sql .= ' ORDER BY id DESC LIMIT ' . $limit . ' OFFSET ' . $offset;
    $stmt = db($CONFIG)->prepare($sql);
    $stmt->execute($bind);
    $items = array_map('_claim_row', $stmt->fetchAll());
    send_json(['items' => $items]);
}

function route_admin_get_claim(array $CONFIG, int $instId): void
{
    require_admin($CONFIG);
    $pdo = db($CONFIG);
    $stmt = $pdo->prepare('SELECT * FROM institutions WHERE id = ?');
    $stmt->execute([$instId]);
    $inst = $stmt->fetch();
    if (!$inst) send_error('Not found', 404);
    $stmt = $pdo->prepare('SELECT id, doc_type, filename, content_type, uploaded_at FROM claim_documents WHERE institution_id = ? ORDER BY id DESC');
    $stmt->execute([$instId]);
    $docs = array_map(function ($d) {
        $d['id'] = (int)$d['id'];
        return $d;
    }, $stmt->fetchAll());
    // Owner contact info
    $owner = null;
    if (!empty($inst['owner_user_id'])) {
        $stmt = $pdo->prepare('SELECT id, phone, email, name FROM users WHERE id = ?');
        $stmt->execute([(int)$inst['owner_user_id']]);
        $owner = $stmt->fetch() ?: null;
    }
    send_json(['institution' => _claim_row($inst), 'documents' => $docs, 'owner' => $owner]);
}

function route_admin_decide(array $CONFIG, int $instId): void
{
    $admin = require_admin($CONFIG);
    $data = read_json_body();
    $decision = (string)require_param($data, 'decision'); // approve | reject | needs_info | suspend
    $notes = (string)($data['notes'] ?? '');
    $allowed = ['approve','reject','needs_info','suspend'];
    if (!in_array($decision, $allowed, true)) send_error('Invalid decision', 400);

    $pdo = db($CONFIG);
    $stmt = $pdo->prepare('SELECT * FROM institutions WHERE id = ?');
    $stmt->execute([$instId]);
    $inst = $stmt->fetch();
    if (!$inst) send_error('Not found', 404);

    $now = db_now($CONFIG);
    $dnsInfo = null;

    if ($decision === 'approve') {
        $cf = cf_create_record($CONFIG, $inst['brand'], $inst['slug']);
        $dnsInfo = $cf;
        $cfRecordId = $cf['ok'] ? $cf['record_id'] : ($inst['cf_record_id'] ?? null);
        $dnsStatus = $cf['attempted'] ? ($cf['ok'] ? 'live' : 'error') : 'manual';
        $pdo->prepare(
            'UPDATE institutions SET status = ?, review_notes = ?, verified_at = ?,
             cf_record_id = ?, dns_status = ?, dns_message = ? WHERE id = ?'
        )->execute(['verified', $notes ?: null, $now, $cfRecordId, $dnsStatus, $cf['message'], $instId]);
    } elseif ($decision === 'reject') {
        // Best-effort DNS cleanup if a record was previously created.
        if (!empty($inst['cf_record_id'])) {
            cf_delete_record($CONFIG, $inst['brand'], $inst['cf_record_id'], $inst['slug']);
        }
        $pdo->prepare(
            'UPDATE institutions SET status = ?, review_notes = ?, cf_record_id = NULL, dns_status = NULL, dns_message = NULL WHERE id = ?'
        )->execute(['rejected', $notes ?: null, $instId]);
    } elseif ($decision === 'needs_info') {
        $pdo->prepare(
            'UPDATE institutions SET status = ?, review_notes = ? WHERE id = ?'
        )->execute(['needs_info', $notes ?: null, $instId]);
    } else { // suspend
        if (!empty($inst['cf_record_id'])) {
            cf_delete_record($CONFIG, $inst['brand'], $inst['cf_record_id'], $inst['slug']);
        }
        $pdo->prepare(
            'UPDATE institutions SET status = ?, review_notes = ?, dns_status = ?, cf_record_id = NULL WHERE id = ?'
        )->execute(['suspended', $notes ?: null, 'suspended', $instId]);
    }
    audit($CONFIG, (int)$admin['id'], $instId, 'admin.decide.' . $decision, $notes);
    $stmt->execute([$instId]);
    send_json(['ok' => true, 'institution' => _claim_row($stmt->fetch()), 'dns' => $dnsInfo]);
}

function route_admin_doc_download(array $CONFIG, int $docId): void
{
    require_admin($CONFIG);
    $stmt = db($CONFIG)->prepare('SELECT filename, stored_path, content_type FROM claim_documents WHERE id = ?');
    $stmt->execute([$docId]);
    $row = $stmt->fetch();
    if (!$row || !file_exists($row['stored_path'])) send_error('Not found', 404);
    header('Content-Type: ' . $row['content_type']);
    header('Content-Disposition: inline; filename="' . basename($row['filename']) . '"');
    header('Content-Length: ' . filesize($row['stored_path']));
    readfile($row['stored_path']);
    exit;
}

function route_admin_reserved_list(array $CONFIG): void
{
    require_admin($CONFIG);
    $stmt = db($CONFIG)->query('SELECT id, slug, reason, created_at FROM reserved_slugs ORDER BY slug ASC');
    $items = array_map(function ($r) {
        $r['id'] = (int)$r['id'];
        return $r;
    }, $stmt->fetchAll());
    send_json(['items' => $items]);
}

function route_admin_reserved_add(array $CONFIG): void
{
    require_admin($CONFIG);
    $data = read_json_body();
    $slug = normalize_slug((string)require_param($data, 'slug'));
    [$ok, $err] = slug_format_validity($slug);
    if (!$ok) send_error($err, 400);
    $reason = $data['reason'] ?? null;
    try {
        db($CONFIG)->prepare(
            'INSERT INTO reserved_slugs (slug, reason, created_at) VALUES (?,?,?)'
        )->execute([$slug, $reason, db_now($CONFIG)]);
    } catch (PDOException $e) {
        send_error('Already reserved', 409);
    }
    audit($CONFIG, null, null, 'admin.reserved.add', $slug);
    send_json(['ok' => true, 'slug' => $slug]);
}

function route_admin_reserved_delete(array $CONFIG, int $id): void
{
    require_admin($CONFIG);
    db($CONFIG)->prepare('DELETE FROM reserved_slugs WHERE id = ?')->execute([$id]);
    audit($CONFIG, null, null, 'admin.reserved.delete', (string)$id);
    send_json(['ok' => true]);
}

function route_admin_dns_retry(array $CONFIG, int $instId): void
{
    $admin = require_admin($CONFIG);
    $stmt = db($CONFIG)->prepare('SELECT * FROM institutions WHERE id = ?');
    $stmt->execute([$instId]);
    $inst = $stmt->fetch();
    if (!$inst) send_error('Not found', 404);
    if ($inst['status'] !== 'verified') send_error('Tenant must be verified', 400);
    $cf = cf_create_record($CONFIG, $inst['brand'], $inst['slug']);
    db($CONFIG)->prepare(
        'UPDATE institutions SET cf_record_id = ?, dns_status = ?, dns_message = ? WHERE id = ?'
    )->execute([
        $cf['ok'] ? $cf['record_id'] : ($inst['cf_record_id'] ?? null),
        $cf['attempted'] ? ($cf['ok'] ? 'live' : 'error') : 'manual',
        $cf['message'],
        $instId,
    ]);
    audit($CONFIG, (int)$admin['id'], $instId, 'admin.dns.retry');
    send_json(['ok' => $cf['ok'], 'dns' => $cf]);
}
